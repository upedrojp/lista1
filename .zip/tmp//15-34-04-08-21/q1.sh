#!/bin/bash
echo -e "A persistência é o caminho do êxito"
