# Lista 1 - Pedro Lucas
IFPB PS 2021.1 Lista 1
