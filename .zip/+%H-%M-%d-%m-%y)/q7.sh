#!/bin/bash
read -p "Digite um número inteiro: " x
echo $(($x + 134))
