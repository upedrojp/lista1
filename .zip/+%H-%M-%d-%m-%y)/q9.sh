#!/bin/bash

e1="$((($1 + 1) * ($2 -1)))"

echo -e $e1
