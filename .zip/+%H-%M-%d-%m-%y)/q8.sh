#!/bin/bash
soma=$(( $1 + $2 + $3))
echo -e "$soma"
